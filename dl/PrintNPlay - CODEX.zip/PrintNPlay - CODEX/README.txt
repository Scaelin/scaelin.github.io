Bonjour, et merci d'essayer CODEX en version Print'n'Play !

En plus des cartes que vous allez imprimer, il vous faudra environ 8 dés à 6 face. Ces dés sont potentiellement optionnels, dans la mesure où ils servent à comptabiliser les points de vie des joueurs et des créatures, donc vous pouvez utiliser ce que vous avez sous la main (des cubes de bois, des jetons, etc.)

Les cartes de la version Print'n'Play n'ont pas de dos de carte distinct pour des raisons de practicalité. Les dos unis ne sont pas un problème, mais selon la densité du papier il est possible de voir de quelle carte il s'agit à travers la carte. La méthode que j'utilise avec mes prototypes est de placer les cartes découpées dans des protège cartes (format standard, 63x88), et éventuellement d'y glisser une carte à jouer standard derrière, pour améliorer la rigidité et le confort de jeu. Tout ceci reste normalement optionnel cependant. Si vous souhaitez le faire, sachez qu'il y a au total 83 cartes dans INDEX.

Enfin, normalement les différents PDF séparent les différents types de cartes, pour faciliter la mise en place, mais il y a cependant certaines cartes à retirer de leur piles respectives :
- Dans les créatures, il faut retirer tous les exemplaires de "Encre" (4) et de "Piège à loup" (2),  qui vont former la pile de créatures spéciales, qui apparaissent spécifiquement selon certaines conditions.
- Dans les Boss, "Ermite Mycophage" est à placer dans la pile des créatures spéciales également.
- Dans les objets, il faut retirer les 12 objets qui contiennent des chiffres dans leur nom (par exemple "1 - Potion de Conscience"), et ces 12 objets forment la pile des Secrets, qui seront récupérables différemment des objets normaux.
- Ajoutez à la pile des Secrets les trois cartes d'aptitudes de Boss.

En temps normal, les cartes de la pile des Secrets ne sont pas vues par les joueurs avant d'être révélées en jeu, et portent leur numéro sur le dos de la carte, mais pour des raisons de practicalité, encore une fois, il n'y a pas de dos de carte sur la version Print'n'Play.

Normalement, une fois cela effectué, il ne vous reste plus qu'à lire les règles du jeu !
Encore merci, et si vous avez des retours sur n'importe quel aspect du jeu, y compris la méthode de Print'n'Play, je serais ravi de les entendre. Vous pouvez me contacter par mail (owen.davies@laposte.net) ou par message sur Discord (Scaelin#4471).

Bon jeu!